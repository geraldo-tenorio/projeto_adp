#Menu Usuario


def exibir_menu_usuario():
 adicionar_usuario()
 listar_usuarios ()
 buscar_usuario ()
 remover_usuario ()
 iniciar_usuario ()

