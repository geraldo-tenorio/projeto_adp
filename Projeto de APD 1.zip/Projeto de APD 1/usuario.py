#Usuario

def adicionar_usuario(cpf,nome,email,senha):
    cpf = int(input("Informe o seu cpf:  "))
    nome = str(input("Informe o seu nome completo: "))
    email =str(input("Informe o seu e-mail: "))
    senha = int(input("Informe a sua senha: "))
pass

def listar_usuarios ():
    if usuarios != null:
        print(usuarios)

    else:
         print ("Erro!")
pass
def buscar_usuario (cpf):
    for i in range (len(cpf)):
        if usuario [i] == usuario:
            return usuario                        
pass
def remover_usuario (cpf):
    if cpf == cpf:
        usuario.remove(cpf)
        print ("Usuario removido com sucesso! "+usuario+cpf)           
        return (cpf, usuario)
def iniciar_usuarios ():
   pass                 
