#Filme

def adicionar_filme (titulo,genero,ano):
    titulo= str(input("informe o nome do filme: "))
    genero= str(input("informe o nome do filme: "))
    ano= int(input("informe o nome do filme: "))
    return filme

def listar_filmes ():
    if filmes != "":
     print (filmes)
    return filmes

def buscar_filmes(cod_filme):
    for i in range(len(cod_filme)):
#Verificar se o código informado é o mesmo da lista                   
         if cod_filme == cod_filme:          
           print(filme)
         return filme
                   
def buscar_filmes_por_genero(genero):
    for i in range(len(genero)):
           print(filme)
           return  filme
                   
def remover_filme  (cod_filme):
    if cod_filme == cod_filme:
        cod_filme.remove(cod_filme)
        print(filme)
        return filme

