#Principal
import usuario
import filme
import MenuUsuario
import MenuFilme


def exibir_menu_principal():
        alterar_senha()
        realizar_cadastro()
        verificar_historico ()
        realizar_login ()

adicionar_filme()
