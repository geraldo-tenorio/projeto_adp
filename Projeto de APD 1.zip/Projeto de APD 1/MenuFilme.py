#Menu Filme

def exibir_menu_filme():
 adicionar_filme ()
 listar_filme ()
 buscar_filme ()
 buscar_filmes_por_genero ()
 remover_filme ()
